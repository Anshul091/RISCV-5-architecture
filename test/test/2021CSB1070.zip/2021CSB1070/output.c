#include <stdio.h>

int main(){
    
    
    printf("ANSHUL IS DOING AN ASSIGNMENT\n"); 
    return 0;
}