#include <stdio.h>

int main(){
    


    
    
    
    
    printf("AKSHAT IS DOING AN ASSIGNMENT\n"); 
    return 0;
}